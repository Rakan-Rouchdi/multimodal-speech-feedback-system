| dimension | baseline_variant | multimodal_MAE | baseline_MAE | MAE_improvement | MAE_improvement_pct | multimodal_spearman | baseline_spearman | spearman_delta | multimodal_pearson | baseline_pearson | pearson_delta |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| confidence | speech_only | 14.225 | 21.21 | 6.985 | 32.9326 | 0.7417 | 0.2803 | 0.4614 | 0.7074 | 0.2935 | 0.4139 |
| confidence | text_only | 14.225 | 16.175 | 1.95 | 12.0556 | 0.7417 | 0.7254 | 0.0162 | 0.7074 | 0.6491 | 0.0583 |
| clarity | speech_only | 13.7 | 18.595 | 4.895 | 26.3243 | 0.7148 | 0.0575 | 0.6574 | 0.694 | -0.0058 | 0.6998 |
| clarity | text_only | 13.7 | 14.12 | 0.42 | 2.9745 | 0.7148 | 0.7285 | -0.0137 | 0.694 | 0.6903 | 0.0037 |
| engagement | speech_only | 17.22 | 17.695 | 0.475 | 2.6844 | 0.5842 | 0.4026 | 0.1816 | 0.5459 | 0.4171 | 0.1288 |
| engagement | text_only | 17.22 | 19.155 | 1.935 | 10.1018 | 0.5842 | 0.4661 | 0.1181 | 0.5459 | 0.4501 | 0.0959 |
