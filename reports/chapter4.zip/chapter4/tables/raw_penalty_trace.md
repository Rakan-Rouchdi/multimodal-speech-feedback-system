| participant_id | initial_confidence | initial_clarity | initial_engagement | fluency_penalty | final_confidence | final_clarity | final_engagement | filler_rate_pct | pause_ratio | trigger_reason | human_confidence_mean | human_clarity_mean | human_engagement_mean | total_score_change |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S01_T1 | 65.6301 | 59.8573 | 70.5248 | 110.5331 | 63.4195 | 56.5413 | 66.1035 | 11.6402 | 0.0795 | filler_score below 100; pause_ratio_score below 100 | 95 | 80 | 90 | 9.9479 |
| S01_T2 | 57.5747 | 54.5243 | 63.0586 | 129.0396 | 54.9939 | 50.6532 | 57.8971 | 7.5581 | 0.0587 | filler_score below 100; repeat_score below 100 | 75 | 65 | 75 | 11.6134 |
| S02_T1 | 77.4167 | 75.7359 | 83.8313 | 99.7653 | 75.4214 | 72.7429 | 79.8406 | 2.1277 | 0 | filler_score below 100; repeat_score below 100 | 65 | 65 | 40 | 8.979 |
| S02_T2 | 61.6645 | 55.8481 | 67.8231 | 177.9616 | 58.1053 | 50.5092 | 60.7046 | 14.5455 | 0.0748 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 40 | 45 | 30 | 16.0166 |
| S03_T1 | 85.5737 | 85.5145 | 79.2951 | 55.1899 | 84.4699 | 83.8588 | 77.0875 | 0 | 0.1197 | pause_ratio_score below 100 | 80 | 80 | 65 | 4.9671 |
| S03_T2 | 73.8061 | 71.586 | 77.0327 | 160.2779 | 70.6006 | 66.7777 | 70.6216 | 3.1579 | 0.1064 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 90 | 75 | 65 | 14.4249 |
| S04_T1 | 78.9822 | 78.9603 | 84.6836 | 102.0833 | 76.9405 | 75.8978 | 80.6002 | 0.6803 | 0 | repeat_score below 100 | 95 | 100 | 100 | 9.1876 |
| S04_T2 | 91.6456 | 92.6252 | 91.6292 | 1.6389 | 91.6128 | 92.576 | 91.5637 | 0 | 0.0715 | pause_ratio_score below 100 | 95 | 80 | 100 | 0.1475 |
| S05_T1 | 54.9798 | 52.6799 | 60.6087 | 384.5042 | 47.2897 | 41.1448 | 45.2285 | 2.1898 | 0.1246 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 45 | 45 | 75 | 34.6054 |
| S05_T2 | 44.9534 | 39.1989 | 50.2926 | 360.6334 | 37.7407 | 28.3799 | 35.8673 | 11.1765 | 0.1863 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 30 | 50 | 75 | 32.457 |
| S06_T1 | 81.4019 | 82.3656 | 83.1817 | 74.7166 | 79.9076 | 80.1241 | 80.1931 | 1.8018 | 0.0431 | filler_score below 100; repeat_score below 100 | 50 | 50 | 65 | 6.7244 |
| S06_T2 | 85.1615 | 85.7131 | 86.3236 | 23.2432 | 84.6966 | 85.0158 | 85.3939 | 2.1622 | 0.0242 | filler_score below 100 | 50 | 55 | 75 | 2.0919 |
| S07_T1 | 93.7877 | 93.2442 | 94.7184 | 59.2083 | 92.6036 | 91.4679 | 92.3501 | 0 | 0.0719 | repeat_score below 100; pause_ratio_score below 100 | 100 | 100 | 95 | 5.3287 |
| S07_T2 | 92.0956 | 91.183 | 91.8 | 50.8124 | 91.0794 | 89.6586 | 89.7675 | 1.6 | 0.1049 | filler_score below 100; pause_ratio_score below 100 | 100 | 100 | 95 | 4.5731 |
| S08_T1 | 37.7337 | 35.6684 | 41.4569 | 405.8364 | 29.617 | 23.4933 | 25.2235 | 9.2105 | 0.126 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 40 | 45 | 35 | 36.5252 |
| S08_T2 | 44.2726 | 40.8338 | 48.5117 | 326.2526 | 37.7475 | 31.0463 | 35.4616 | 11.6402 | 0.1387 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 25 | 25 | 25 | 29.3627 |
| S09_T1 | 77.6647 | 76.8348 | 77.9114 | 160.0252 | 74.4642 | 72.0341 | 71.5104 | 2.6786 | 0.1303 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 50 | 45 | 70 | 14.4022 |
| S09_T2 | 54.6018 | 53.5905 | 57.3849 | 348.9695 | 47.6224 | 43.1215 | 43.4261 | 3 | 0.1069 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 50 | 50 | 60 | 31.4072 |
| S10_T1 | 70.3451 | 72.0889 | 67.5103 | 165.8205 | 67.0287 | 67.1143 | 60.8775 | 2.027 | 0.1081 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 50 | 75 | 40 | 14.9238 |
| S10_T2 | 77.638 | 76.7847 | 78.7995 | 75.5873 | 76.1262 | 74.5171 | 75.776 | 2.9412 | 0.076 | filler_score below 100; repeat_score below 100; pause_ratio_score below 100 | 75 | 75 | 50 | 6.8029 |
