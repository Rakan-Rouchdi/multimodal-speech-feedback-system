| row_type | variant | active_evidence | purpose | metric | meaning | interpretation |
| --- | --- | --- | --- | --- | --- | --- |
| variant | speech_only | acoustic metrics only | audio-only baseline |  |  |  |
| variant | text_only | CrisperWhisper transcript and text metrics | linguistic-only baseline |  |  |  |
| variant | multimodal | acoustic metrics plus transcript/text metrics | full system comparison |  |  |  |
| metric |  |  |  | MAE | mean absolute difference between human reference and system score on 0-100 scale | lower is better |
| metric |  |  |  | Pearson r | linear association with human reference scores | higher positive values indicate stronger linear alignment |
| metric |  |  |  | Spearman rho | rank-order association with human reference scores | higher positive values indicate stronger ranking alignment |
