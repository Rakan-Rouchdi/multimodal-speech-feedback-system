| dimension | best_variant_by_MAE | best_variant_by_Pearson | best_variant_by_Spearman | observation |
| --- | --- | --- | --- | --- |
| confidence | multimodal | multimodal | multimodal | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; multimodal has the strongest Spearman correlation. |
| clarity | multimodal | multimodal | text_only | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; text_only has the strongest Spearman correlation. |
| engagement | multimodal | multimodal | multimodal | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; multimodal has the strongest Spearman correlation. |
