| participant_id | fluency_penalty | confidence_reduction | clarity_reduction | engagement_reduction | initial_confidence | final_confidence | initial_clarity | final_clarity | initial_engagement | final_engagement | human_confidence | human_clarity | human_engagement |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S08_T1 | 405.8364 | 8.1167 | 12.1751 | 16.2335 | 37.7337 | 29.617 | 35.6684 | 23.4933 | 41.4569 | 25.2235 | 40 | 45 | 35 |
