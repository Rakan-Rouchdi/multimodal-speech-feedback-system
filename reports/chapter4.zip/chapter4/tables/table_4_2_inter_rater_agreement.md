| dimension | mean_human_score | mean_rater_std | median_rater_std | min_rater_std | max_rater_std | cronbach_alpha | interpretation |
| --- | --- | --- | --- | --- | --- | --- | --- |
| confidence | 65 | 6.0927 | 5.5902 | 0 | 13.6931 | 0.9831 | high agreement |
| clarity | 65.25 | 5.8414 | 5.5902 | 0 | 13.6931 | 0.973 | high agreement |
| engagement | 66.25 | 7.7133 | 11.1803 | 0 | 13.6931 | 0.9726 | high agreement |
