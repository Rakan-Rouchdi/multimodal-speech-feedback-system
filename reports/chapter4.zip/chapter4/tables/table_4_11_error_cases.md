| participant_id | dimension | variant | human_score | system_score | absolute_error | likely_error_type | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| S01_T1 | confidence | text_only | 95 | 50.4 | 44.6 | high filler/disfluency rate may dominate text score | fillers/100w: 11.6; repeat rate: 0 |
| S04_T1 | clarity | speech_only | 100 | 56 | 44 | speech-only variant lacks linguistic content evidence | WPM: 0; pause ratio: 0; pitch std: 14.3 |
| S02_T2 | engagement | speech_only | 30 | 70.6 | 40.6 | heuristic score differs from human reference | WPM: 0; pause ratio: 0.0748; pitch std: 12.1 |
