# Latency Interpretation Notes

The Chapter 4 latency analysis is computed from the `latency_ms` fields already stored in the existing raw JSON outputs under `outputs/main_eval/raw/`.

These timings therefore describe the recorded batch output files, not a fresh uncached benchmark run.

- Text-enabled rows analysed: 40.
- Transcription cache enabled in logged outputs: yes.
- Logged transcription cache hits: 40.
- Mean logged transcription stage: 0.0048 seconds.
- Mean logged total runtime: 3.4330 seconds.

Because many text-enabled outputs use cached CrisperWhisper transcriptions, near-zero transcription timings should be interpreted as cache reuse rather than raw transcription speed.
Do not claim real-time performance from these figures. They support a cautious discussion of offline feedback practicality for the logged evaluation run.
