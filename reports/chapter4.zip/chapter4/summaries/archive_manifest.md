# Chapter 4 Legacy Archive Manifest

- Timestamp: `20260426_191021`
- Mode: `archive`
- Archive directory: `outputs/archive/chapter4_legacy_20260426_191021`

## Safety Checks Performed

- Confirmed current Chapter 4 generation uses `outputs/main_eval/raw/**` JSON files as system output source.
- Confirmed current Chapter 4 generation uses `outputs/main_eval/Raters - Rater *.csv` as human rating source.
- Confirmed legacy merged and previous human-evaluation summary files are not required by `analysis/generate_chapter4_outputs.py`.
- Excluded raw audio, raw JSON outputs, rater files, `human_scores.csv`, `main_eval_results.csv`, transcription cache, reports, analysis scripts, and pilot outputs from automatic archiving.

## Files Moved

| Original path | Archive path | Reason | Status |
|---|---|---|---|
| `outputs/main_eval/final_merged.csv` | `outputs/archive/chapter4_legacy_20260426_191021/final_merged.csv` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |
| `outputs/main_eval/final_mergedoriginal.csv` | `outputs/archive/chapter4_legacy_20260426_191021/final_mergedoriginal.csv` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |
| `outputs/main_eval/human_evaluation_overall.csv` | `outputs/archive/chapter4_legacy_20260426_191021/human_evaluation_overall.csv` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |
| `outputs/main_eval/human_evaluation_report.md` | `outputs/archive/chapter4_legacy_20260426_191021/human_evaluation_report.md` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |
| `outputs/main_eval/human_evaluation_summary.csv` | `outputs/archive/chapter4_legacy_20260426_191021/human_evaluation_summary.csv` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |
| `outputs/main_eval/main_eval_resultsoriginal.csv` | `outputs/archive/chapter4_legacy_20260426_191021/main_eval_resultsoriginal.csv` | Legacy/stale Chapter 4 evaluation output superseded by regenerated reports. | moved |

## Files Intentionally Retained

- `outputs/main_eval/raw/**`
- `outputs/main_eval/Raters - Rater *.csv`
- `outputs/main_eval/human_scores.csv`
- `outputs/main_eval/main_eval_results.csv`
- `data/main_eval/**`
- `outputs/cache/**`
- `reports/chapter4/**`
- `analysis/chapter4_evaluation.ipynb`
- `analysis/generate_chapter4_outputs.py`
- `outputs/pilot/**`
