# Chapter 4 Evaluation Workspace README

This workspace contains reproducible Chapter 4 analysis artefacts for the dissertation evaluation.

## Source Inputs

- `outputs/main_eval/raw/**`: raw JSON outputs from `speech_only`, `text_only`, and `multimodal` pipeline runs.
- `outputs/main_eval/Raters - Rater *.csv`: individual human rater files.
- `outputs/main_eval/human_scores.csv`: retained aggregate human score reference, used as fallback only if individual rater files are unavailable.
- `data/main_eval/**`: evaluation audio recordings, retained untouched.
- `outputs/cache/**`: transcription cache, retained untouched.

## Generated Outputs

- `reports/chapter4/tables/`: Chapter 4 CSV and Markdown tables.
- `reports/chapter4/figures/`: original generated figures.
- `reports/chapter4/figures/polished/`: report-ready PNG/PDF figures with dissertation-friendly labels.
- `reports/chapter4/summaries/`: inventory, result summaries, latency notes, missing-data report, and archive manifest.
- `analysis/chapter4_evaluation.ipynb`: the notebook dashboard.

## Rerun Commands

Generate current tables, figures, and summaries:

```bash
python analysis/generate_chapter4_outputs.py
```

Generate everything including polished figures and the notebook dashboard:

```bash
python analysis/generate_chapter4_outputs.py --generate --polish --notebook-dashboard
```

Preview legacy cleanup without moving files:

```bash
python analysis/generate_chapter4_outputs.py --cleanup-legacy --dry-run
```

Archive legacy files after reviewing the dry run:

```bash
python analysis/generate_chapter4_outputs.py --cleanup-legacy
```

## Notebook

Open `analysis/chapter4_evaluation.ipynb` in Jupyter or VS Code. The script is still the canonical reproducible execution path if Jupyter is not installed in the virtual environment.

## Why Archive Instead of Delete?

Legacy evaluation files are moved to `outputs/archive/chapter4_legacy_<timestamp>/` rather than deleted so older analysis outputs remain auditable while the active Chapter 4 workspace stays clean.
