# Chapter 4 Results Summary

All values in this summary were recomputed by `analysis/generate_chapter4_outputs.py` from repository files.

## 1. Data Used

- Participant recording IDs analysed: 20.
- Distinct speaker prefixes: 10.
- Human raters: 5.
- System variants: speech_only, text_only, multimodal.
- Human rating scale detected: 1-5.
- Human scores scaled to 0-100: yes.

## 2. Inter-Rater Agreement

| dimension | mean_rater_std | cronbach_alpha | interpretation |
| --- | --- | --- | --- |
| confidence | 6.0927 | 0.9831 | high agreement |
| clarity | 5.8414 | 0.973 | high agreement |
| engagement | 7.7133 | 0.9726 | high agreement |


## 3. Main Quantitative Finding

- Best variant by mean MAE: `multimodal` (15.0483).
- Best variant by mean Pearson: `multimodal` (0.6491).
- Best variant by mean Spearman: `multimodal` (0.6802).

Multimodal deltas against unimodal variants:
| baseline_variant | mean_MAE_improvement | mean_spearman_delta | mean_pearson_delta |
| --- | --- | --- | --- |
| speech_only | 4.1183 | 0.4335 | 0.4142 |
| text_only | 1.435 | 0.0402 | 0.0526 |


## 4. Dimension-Level Finding

| dimension | best_variant_by_MAE | best_variant_by_Pearson | best_variant_by_Spearman | observation |
| --- | --- | --- | --- | --- |
| confidence | multimodal | multimodal | multimodal | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; multimodal has the strongest Spearman correlation. |
| clarity | multimodal | multimodal | text_only | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; text_only has the strongest Spearman correlation. |
| engagement | multimodal | multimodal | multimodal | multimodal has the lowest MAE; multimodal has the strongest Pearson correlation; multimodal has the strongest Spearman correlation. |


## 5. Feature-Level Finding

- Confidence: repetition_rate (rho=-0.6483), filler_rate_pct (rho=-0.5967), filler_count (rho=-0.5766)
- Clarity: filler_rate_pct (rho=-0.6309), repetition_rate (rho=-0.5817), filler_count (rho=-0.5689)
- Engagement: filler_rate_pct (rho=-0.4928), repetition_rate (rho=-0.4468), filler_count (rho=-0.445)

## 6. Case Studies Selected

- strong speaker: `S07_T1`. Highest human reference average, with closeness to multimodal scores used as tie-breaker.
- weak/mixed speaker: `S01_T1`. Largest mean absolute difference between multimodal system scores and human reference scores.

## 7. Cross-Modality Penalty

- Penalty data was derived non-invasively from current scoring formulas. Selected example: `S08_T1` with fluency penalty 405.8364.
- Alignment effect should be discussed by comparing initial and final scores against the human reference in Table 4.9.

## 8. Latency

- Mean total runtime: 3.4330 seconds.
- Slowest mean stage: `acoustic_extraction` (3.3559 seconds).
- Current timings support discussion of offline feedback practicality; they should not be presented as hardware-independent benchmarks.

## 9. Error Analysis

| participant_id | dimension | variant | human_score | system_score | absolute_error | likely_error_type | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| S01_T1 | confidence | text_only | 95 | 50.4 | 44.6 | high filler/disfluency rate may dominate text score | fillers/100w: 11.6; repeat rate: 0 |
| S04_T1 | clarity | speech_only | 100 | 56 | 44 | speech-only variant lacks linguistic content evidence | WPM: 0; pause ratio: 0; pitch std: 14.3 |
| S02_T2 | engagement | speech_only | 30 | 70.6 | 40.6 | heuristic score differs from human reference | WPM: 0; pause ratio: 0.0748; pitch std: 12.1 |


## 10. Missing Data

- No required core data files were missing.
